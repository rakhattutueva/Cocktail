﻿using CocktailDBTest.CommonFunctions;
using CocktailDBTest.Enums;
using CocktailDBTest.Model;
using NUnit.Framework;



namespace CocktailDBTest.Tests
{
    [TestFixture]
    public class TestCocktailByIngredient
    {
        private string baseUrl = TestDataConfig.ConfigReader().BaseUrl;
        private string nonAlcoholIngred = TestDataConfig.ConfigReader().NonAlcoholIngred;
        private string alcoholIngred = TestDataConfig.ConfigReader().AlcoholIngred;

        //Verify status code 200 
        [Test]
        public void GivenUser_Verifies_StatusCode200_WhenSuccessGet()
        {
            HttpResponseMessage httpResponseMessage = RequestGenerator.SendRequest(baseUrl, QueryCriteria.INGRED_NAME, nonAlcoholIngred);
            Assert.AreEqual(200,(int)httpResponseMessage.StatusCode);

        }

        //If an ingredient is non-alcoholic, Alcohol is no and ABV is null
        [Test]
        public void GivenUser_Verifies_AlcoholABVNull_if_IngredientIsNonAlcoholic()
        {
            HttpResponseMessage httpResponseMessage = RequestGenerator.SendRequest(baseUrl, QueryCriteria.INGRED_NAME, nonAlcoholIngred);
            ListOfIngredients listOfIngredients =  RequestGenerator.ReadResponseMessageAndReturnListOfIngreds(httpResponseMessage);

            for (int i = 0; i < listOfIngredients.Ingredients.Count; i++)
            {
                string eachStrAlcohol = listOfIngredients.Ingredients[i].StrAlcohol;
                string eachStrABV = listOfIngredients.Ingredients[i].StrABV;
                Assert.True(eachStrAlcohol.ToLower().Contains("no"));
                Assert.IsNull(eachStrABV);
            }

        }


        //If an ingredient is alcoholic, Alcohol is yes and ABV is not null.
        [Test]
        public void GivenUser_Verifies_AlcoholFieldValueIsYes_if_IngredientIsAlcoholic()
        {

            HttpResponseMessage httpResponseMessage = RequestGenerator.SendRequest(baseUrl, QueryCriteria.INGRED_NAME,alcoholIngred);
            ListOfIngredients listOfIngredients = RequestGenerator.ReadResponseMessageAndReturnListOfIngreds(httpResponseMessage);

            for(int i = 0; i < listOfIngredients.Ingredients.Count;  i++)
            {
                Assert.True(listOfIngredients.Ingredients[i].StrAlcohol.ToLower().Contains("yes"));
                Assert.IsNotNull(listOfIngredients.Ingredients[i].StrABV);

            }            
        }

        [Test]
        public void GivenUser_Verifies_IdIngredientIsNotNullOrEmpty() {
            HttpResponseMessage httpResponseMessage = RequestGenerator.SendRequest(baseUrl, QueryCriteria.INGRED_NAME, alcoholIngred);
            ListOfIngredients listOfIngredients = RequestGenerator.ReadResponseMessageAndReturnListOfIngreds(httpResponseMessage);

            for (int i = 0; i < listOfIngredients.Ingredients.Count; i++)
            {
                Assert.IsNotNull(listOfIngredients.Ingredients[i].IdIngredient);
                Assert.IsNotEmpty(listOfIngredients.Ingredients[i].IdIngredient);
            }


        }

    }
}
