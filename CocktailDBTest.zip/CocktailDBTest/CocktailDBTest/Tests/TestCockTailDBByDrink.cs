﻿using CocktailDBTest.CommonFunctions;
using CocktailDBTest.Enums;
using CocktailDBTest.Model;
using NUnit.Framework;

namespace CocktailDBTest.Tests
{
    public class TestCockTailDBByDrink
    {
        private string baseUrl = TestDataConfig.ConfigReader().BaseUrl;
        private string cockTailName = TestDataConfig.ConfigReader().CockTailName;
        private string nonExistentDrink = TestDataConfig.ConfigReader().NonExistentDrink;
        private string upperLowerCaseDrink = TestDataConfig.ConfigReader().UpperLowerCaseDrink;

        [Test]
        public void Given_UserVerifies_RequestReturnsNotNull_if_CocktailExistInDb()
        {
          HttpResponseMessage httpResponseMessage =   RequestGenerator.SendRequest(baseUrl,QueryCriteria.COCKTAIL_NAME,cockTailName);
            ListOfDrinks listOfDrinks = RequestGenerator.ReadResponseMessageAndReturnListOfDrinks(httpResponseMessage);
            Assert.IsNotNull(listOfDrinks.Drinks);          
        }

        [Test]
        public void Given_UserVerifies_RequestReturnsNull_if_CocktailDoesNotExistInDb()
        {
            HttpResponseMessage httpResponseMessage = RequestGenerator.SendRequest(baseUrl, QueryCriteria.COCKTAIL_NAME, nonExistentDrink);
            ListOfDrinks listOfDrinks = RequestGenerator.ReadResponseMessageAndReturnListOfDrinks(httpResponseMessage);
            Assert.IsNull(listOfDrinks.Drinks);

        }

        [Test]
        public void Given_UserVerifies_SearchingCocktailByNameIsCaseInsetsitive()
        {
            HttpResponseMessage httpResponseMessage = RequestGenerator.SendRequest(baseUrl, QueryCriteria.COCKTAIL_NAME, upperLowerCaseDrink);
            ListOfDrinks listOfDrinks = RequestGenerator.ReadResponseMessageAndReturnListOfDrinks(httpResponseMessage);
            Assert.IsNotNull(listOfDrinks.Drinks);
           Assert.IsTrue( TestMethods.ContainsSearchedDrink(listOfDrinks, upperLowerCaseDrink));

        }

    }
}
