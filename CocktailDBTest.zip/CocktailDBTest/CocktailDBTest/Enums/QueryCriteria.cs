﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CocktailDBTest.Enums
{
    public enum QueryCriteria
    {
        INGRED_NAME, COCKTAIL_NAME
    }
}
