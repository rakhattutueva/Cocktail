﻿using CocktailDBTest.Model;
using Newtonsoft.Json;
using System.Net;
using CocktailDBTest.Enums;

namespace CocktailDBTest.CommonFunctions
{
    internal class RequestGenerator
    {
        public static HttpResponseMessage SendRequest(string baseUrl,QueryCriteria queryCriteria, string queryParam)
        {
            string url = "";
           
            if (queryCriteria.CompareTo(QueryCriteria.INGRED_NAME) == 0)
            {
                url = baseUrl + "?i=" + queryParam;
            }
            else
            {
                url = baseUrl + "?s=" + queryParam;
            }
                //Builing the request 
            HttpRequestMessage httpRequestMessage = new HttpRequestMessage();
            httpRequestMessage.RequestUri = new Uri(url);
            httpRequestMessage.Headers.Add("Accept", "application/json");

            HttpClient httpClient = new HttpClient();

             //Constructing the response mesage 
            Task<HttpResponseMessage> httpResponse = httpClient.SendAsync(httpRequestMessage);
            HttpResponseMessage httpResponseMessage = httpResponse.Result;
          //  Console.WriteLine(httpResponseMessage.ToString());
            return httpResponseMessage;
        }

        public static ListOfIngredients ReadResponseMessageAndReturnListOfIngreds(HttpResponseMessage httpResponseMessage)
        {
                        //Response Data 
            HttpContent responseContent = httpResponseMessage.Content;
            Task<string> responseData = responseContent.ReadAsStringAsync();
            string data = responseData.Result;

            HttpStatusCode httpStatusCode = httpResponseMessage.StatusCode;

            RestResponse restResponse = new RestResponse((int)httpStatusCode, responseData.Result);
       
            ListOfIngredients listOfIngredients = JsonConvert.DeserializeObject<ListOfIngredients>(restResponse.ResponseContent);

         //   Console.WriteLine(listOfIngredients.Ingredients[0].StrAlcohol);
           // Console.WriteLine(listOfIngredients);
            return listOfIngredients;

        }


        public static ListOfDrinks ReadResponseMessageAndReturnListOfDrinks(HttpResponseMessage httpResponseMessage)
        {
            //Response Data 
            HttpContent responseContent = httpResponseMessage.Content;
            Task<string> responseData = responseContent.ReadAsStringAsync();
            string data = responseData.Result;

            HttpStatusCode httpStatusCode = httpResponseMessage.StatusCode;

            RestResponse restResponse = new RestResponse((int)httpStatusCode, responseData.Result);

            ListOfDrinks listOfDrinks = JsonConvert.DeserializeObject<ListOfDrinks>(restResponse.ResponseContent);

            //   Console.WriteLine(listOfIngredients.Ingredients[0].StrAlcohol);
            // Console.WriteLine(listOfIngredients);
            return listOfDrinks;

        }




    }
}
