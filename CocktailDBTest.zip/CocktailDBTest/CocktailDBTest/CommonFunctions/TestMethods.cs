﻿using CocktailDBTest.Model;
using NUnit.Framework;


namespace CocktailDBTest.CommonFunctions
{
    public class TestMethods
    {
        public static Boolean ContainsSearchedDrink(ListOfDrinks listOfDrinks,string searchDrink)
        
        {
            for (int i = 0; listOfDrinks.Drinks.Count > i; i++)
            { 
                string eachDrink = listOfDrinks.Drinks[i].StrDrink;
                if (eachDrink.ToLower().Contains(searchDrink.ToLower()))
                {
                    return true;
                }
                else
                {
                    
                    break;
                  
                }
            }

            return false;
        }


        public static Boolean IsAlcoholicIngredient(ListOfIngredients listOfIngred)

        {
            for (int i = 0; listOfIngred.Ingredients.Count > i; i++)
            {
                string eachIngred = listOfIngred.Ingredients[i].StrAlcohol.ToLower();
                if (eachIngred.ToLower().Contains("yes"))
                {
                    return true;
                }
                else
                {

                    break;

                }
            }

            return false;
        }


        public static void AssertTrueIsAlcoholicIngredient(ListOfIngredients listOfIngred)

        {
            for (int i = 0; listOfIngred.Ingredients.Count > i; i++)
            {
                string eachIngred = listOfIngred.Ingredients[i].StrAlcohol.ToLower();
                Assert.True(eachIngred == "yes");
            }
        }

        public static void AssertFalseIsAlcoholicIngredient(ListOfIngredients listOfIngred)

        {
            for (int i = 0; listOfIngred.Ingredients.Count > i; i++)
            {
                string eachIngred = listOfIngred.Ingredients[i].StrAlcohol.ToLower();
                Assert.True(eachIngred == "no");
            }
        }

    }
}
