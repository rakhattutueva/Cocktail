﻿using Newtonsoft.Json;


namespace CocktailDBTest.Model
{
    public class Drink
    {
        public string? IdDrink { get; set; }
        public string? StrDrink { get; set; }
        public object? StrDrinkAlternate { get; set; }
        public string? StrTags { get; set; }
        public object? StrVideo { get; set; }
        public string? StrCategory { get; set; }
        public string? StrIBA { get; set; }
        public string? StrAlcoholic { get; set; }
        public string? StrGlass { get; set; }
        public string? StrInstructions { get; set; }
        public object? StrInstructionsES { get; set; }
        public string? StrInstructionsDE { get; set; }
        public object? StrInstructionsFR { get; set; }
        public string? StrInstructionsIT { get; set; }

        [JsonProperty("strInstructionsZH-HANS")]
        public object? StrInstructionsZHHANS { get; set; }

        [JsonProperty("strInstructionsZH-HANT")]
        public object? StrInstructionsZHHANT { get; set; }
        public string? StrDrinkThumb { get; set; }
        public string? StrIngredient1 { get; set; }
        public string? StrIngredient2 { get; set; }
        public string? StrIngredient3 { get; set; }
        public string? StrIngredient4 { get; set; }
        public string? StrIngredient5 { get; set; }
        public string? StrIngredient6 { get; set; }
        public string? StrIngredient7 { get; set; }
        public object? StrIngredient8 { get; set; }
        public object? StrIngredient9 { get; set; }
        public object? StrIngredient10 { get; set; }
        public object? StrIngredient11 { get; set; }
        public object? StrIngredient12 { get; set; }
        public object? StrIngredient13 { get; set; }
        public object? StrIngredient14 { get; set; }
        public object? StrIngredient15 { get; set; }
        public string? StrMeasure1 { get; set; }
        public string? StrMeasure2 { get; set; }
        public string? StrMeasure3 { get; set; }
        public string? StrMeasure4 { get; set; }
        public string? StrMeasure5 { get; set; }
        public string? StrMeasure6 { get; set; }
        public string? StrMeasure7 { get; set; }
        public object? StrMeasure8 { get; set; }
        public object? StrMeasure9 { get; set; }
        public object? StrMeasure10 { get; set; }
        public object? StrMeasure11 { get; set; }
        public object? StrMeasure12 { get; set; }
        public object? StrMeasure13 { get; set; }
        public object? StrMeasure14 { get; set; }
        public object? StrMeasure15 { get; set; }
        public string? StrImageSource { get; set; }
        public string? StrImageAttribution { get; set; }
        public string? StrCreativeCommonsConfirmed { get; set; }
        public string? DateModified { get; set; }


        public Drink()
        {

        }

        public Drink(string? idDrink, string? strDrink, object? strDrinkAlternate, string? strTags, object? strVideo, string? strCategory, string? strIBA, string? strAlcoholic, string? strGlass, string? strInstructions, object? strInstructionsES, string? strInstructionsDE, object? strInstructionsFR, string? strInstructionsIT, object? strInstructionsZHHANS, object? strInstructionsZHHANT, string? strDrinkThumb, string? strIngredient1, string? strIngredient2, string? strIngredient3, string? strIngredient4, string? strIngredient5, string? strIngredient6, string? strIngredient7, object? strIngredient8, object? strIngredient9, object? strIngredient10, object? strIngredient11, object? strIngredient12, object? strIngredient13, object? strIngredient14, object? strIngredient15, string? strMeasure1, string? strMeasure2, string? strMeasure3, string? strMeasure4, string? strMeasure5, string? strMeasure6, string? strMeasure7, object? strMeasure8, object? strMeasure9, object? strMeasure10, object? strMeasure11, object? strMeasure12, object? strMeasure13, object? strMeasure14, object? strMeasure15, string? strImageSource, string? strImageAttribution, string? strCreativeCommonsConfirmed, string? dateModified)
        {
            IdDrink = idDrink;
            StrDrink = strDrink;
            StrDrinkAlternate = strDrinkAlternate;
            StrTags = strTags;
            StrVideo = strVideo;
            StrCategory = strCategory;
            StrIBA = strIBA;
            StrAlcoholic = strAlcoholic;
            StrGlass = strGlass;
            StrInstructions = strInstructions;
            StrInstructionsES = strInstructionsES;
            StrInstructionsDE = strInstructionsDE;
            StrInstructionsFR = strInstructionsFR;
            StrInstructionsIT = strInstructionsIT;
            StrInstructionsZHHANS = strInstructionsZHHANS;
            StrInstructionsZHHANT = strInstructionsZHHANT;
            StrDrinkThumb = strDrinkThumb;
            StrIngredient1 = strIngredient1;
            StrIngredient2 = strIngredient2;
            StrIngredient3 = strIngredient3;
            StrIngredient4 = strIngredient4;
            StrIngredient5 = strIngredient5;
            StrIngredient6 = strIngredient6;
            StrIngredient7 = strIngredient7;
            StrIngredient8 = strIngredient8;
            StrIngredient9 = strIngredient9;
            StrIngredient10 = strIngredient10;
            StrIngredient11 = strIngredient11;
            StrIngredient12 = strIngredient12;
            StrIngredient13 = strIngredient13;
            StrIngredient14 = strIngredient14;
            StrIngredient15 = strIngredient15;
            StrMeasure1 = strMeasure1;
            StrMeasure2 = strMeasure2;
            StrMeasure3 = strMeasure3;
            StrMeasure4 = strMeasure4;
            StrMeasure5 = strMeasure5;
            StrMeasure6 = strMeasure6;
            StrMeasure7 = strMeasure7;
            StrMeasure8 = strMeasure8;
            StrMeasure9 = strMeasure9;
            StrMeasure10 = strMeasure10;
            StrMeasure11 = strMeasure11;
            StrMeasure12 = strMeasure12;
            StrMeasure13 = strMeasure13;
            StrMeasure14 = strMeasure14;
            StrMeasure15 = strMeasure15;
            StrImageSource = strImageSource;
            StrImageAttribution = strImageAttribution;
            StrCreativeCommonsConfirmed = strCreativeCommonsConfirmed;
            DateModified = dateModified;
        }


        public override string ToString()
        {
            return JsonConvert.SerializeObject(this);
        }
    }
}
