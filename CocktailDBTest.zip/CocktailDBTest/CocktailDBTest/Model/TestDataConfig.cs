﻿using Microsoft.Extensions.Configuration;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CocktailDBTest.Model
{
    public class TestDataConfig
    {
        public string BaseUrl { get; set; }
        public string NonAlcoholIngred { get; set; }
        public string AlcoholIngred { get; set; }
        public string CockTailName { get; set; }
        public string NonExistentDrink { get; set; }
        public string UpperLowerCaseDrink { get; set; }


        public static TestDataConfig ConfigReader()
        {
            var config = new ConfigurationBuilder()
                .SetBasePath(AppDomain.CurrentDomain.BaseDirectory)
                .AddJsonFile("appsettings.json").Build();

            var section = config.GetSection(nameof(TestDataConfig));
            var testDataConfig = section.Get<TestDataConfig>();
            return testDataConfig;

        }

    }
}
