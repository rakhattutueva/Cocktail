﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CocktailDBTest.Model
{
    public class ListOfDrinks
    {
        public List<Drink> Drinks { get; set; }

        public ListOfDrinks() { }
        public ListOfDrinks(List<Drink> drinks)
        {
            Drinks = drinks;
        }

        public override string ToString()
        {
            return JsonConvert.SerializeObject(this);
        }

    }
}
