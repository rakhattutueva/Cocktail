﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CocktailDBTest.Model
{
    public class Ingredient
    {
        public string? IdIngredient { get; set; }
        public string? StrIngredient { get; set; }
        public string? StrDescription { get; set; }
        public string? StrType { get; set; }
        public string? StrAlcohol { get; set; }
        public string? StrABV { get; set; }

        public Ingredient(string? idIngredient, string? strIngredient, string? strDescription, string? strType, string? strAlcohol, string? strABV)
        {
            IdIngredient = idIngredient;
            StrIngredient = strIngredient;
            StrDescription = strDescription;
            StrType = strType;
            StrAlcohol = strAlcohol;
            StrABV = strABV;
        }

        public Ingredient() { }


        public override string ToString()
        {
            return JsonConvert.SerializeObject(this);
        }

    }

        
}
